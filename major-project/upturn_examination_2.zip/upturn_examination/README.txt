Please don't forget to give credit to original developer because I really worked hard to develop this project and please don't forget to like and share it if you found it useful :)

For students or anyone else who needs program or source code for thesis writing or any Professional Software Development, Website Development, Mobile Apps Development at affordable cost contact me at
Email: mayuri.infospace@gmail.com
skype: DigitalMayu

note: Source Code is only available for educational purpose , plz dont use it for commercial purpose without permission of original author