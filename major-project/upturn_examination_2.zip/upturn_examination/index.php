<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Smart Online Exam System</title>
  
  
  
      <link rel="stylesheet" href="css/style2.css">

  
</head>

<body>
<div>
<center><b><h4>Upturn Smart Online Exam System by Mayuri</h4></b></center>
</div>
  <div class='one'>
  <a href="admin/"><button class='indigo ripple' ripple-color='#5C6BC0'>Admin Login</button></a>
</div>
<div class='two'>
  <a href="student/"><button class='white ripple' ripple-color='white'>Student Login</button></a>
</div>
  



</body>

</html>
