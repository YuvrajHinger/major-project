<?php
    $host="localhost";
    $user="root";
    $password="";
    $database="major_project";
    $con=mysqli_connect($host,$user,$password,$database);    
?>