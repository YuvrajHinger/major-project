<?php
    require_once 'database.php';
    require_once 'layout.php';
?>
