<?php
    session_start();
    if(empty($_SESSION['candidate_id'])) header("Location: login.php");
    require_once 'database.php';
    require_once 'layout.php';
?>
<html>
    <head>
        <?php head(); ?>
    </head>
    <body>
        <div class="page-container">
            <div class="left-content">
                <div class="mother-grid-inner">
                    <ol class="breadcrumb">
			            <center>
                            <li class="breadcrumb-item">
                                <h4><a href="">Dashboard</a></h4>
                            </li>
                        </center>
		            </ol>
                </div>
            </div>
            <?php sidebar(); ?>
        </div>
        <?php script(); ?>
    </body>
</html>