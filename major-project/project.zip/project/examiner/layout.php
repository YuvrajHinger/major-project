<?php
    function head(){                                    ?>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="application/x-javascript"> 
            addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); 
            function hideURLbar(){ window.scrollTo(0,1); } 
        </script>
        <link rel="stylesheet" type="text/css" href="select2/bootstrap-select.min.css"/>
	    <link rel="stylesheet" type="text/css" href="select2/select2.css"/>
	    <link rel="stylesheet" type="text/css" href="select2/multi-select.css"/>
		<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="css/jquery-ui.css"> 
		<link href="css/style.css" rel='stylesheet' type='text/css' />
		<link rel="stylesheet" href="css/morris.css" type="text/css"/>
		<link href="css/font-awesome.css" rel="stylesheet"> 
		<script src="js/jquery-2.1.4.min.js"></script>
		<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
		<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' /> <?php
    }                                                                        
    function sidebar(){                         ?>
        <div class="sidebar-menu">
			<header class="logo1">
				<a onclick="toggleSideBar()" class="sidebar-icon"> 
                    <span class="fa fa-bars"></span> 
                </a> 
			</header>
			<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
            <div class="menu">
                <ul id="menu">
                    <li>
                        <a href="index.php">
                            <i class="fa fa-tachometer"></i> 
                            <span>Dashboard</span>
                            <div class="clearfix"></div>
                        </a>
                    </li>																		 
                    <li id="menu-academico" >
                        <a href="candidate.php">
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <span> Candidate</span> 
                            <div class="clearfix"></div>
                        </a>
                    </li>										 
                    <li id="menu-academico" >
                        <a href="category.php">
                            <i class="fa fa-list-alt" aria-hidden="true"></i>
                            <span>Category</span>                             
                            <div class="clearfix"></div>
                        </a>					    
					</li>										 
				    <li>
                        <a href="add_question.php">
                            <i class="fa fa-question"></i>  
                            <span>Add Question</span>
                            <div class="clearfix"></div>
                        </a>
                    </li>																         
                    <li>
                        <a>
                            <i class="fa fa-sticky-note-o"></i> 
                            <span>Post Exam</span>
                            <span class="fa fa-angle-right" style="float: right"></span>
                            <div class="clearfix"></div>
                        </a>
                        <ul id="menu-academico-sub" >										   
							<li id="menu-academico-avaliacoes" >
                                <a onclick = "alert('working soon');"> Post Exam</a>
                            </li>
							<li id="menu-academico-avaliacoes" >
                                <a onclick = "alert('working soon');"> List Of Exams</a>
                            </li>
						</ul>
                    </li>																		 
					<li>
                        <a onclick="alert('working soon')">
                            <i class="fa fa-asterisk"></i>  
                            <span>Exam Results</span>
                            <div class="clearfix"></div>
                        </a>
                    </li>									
                    <li>
                        <a href="#logout" rel="tooltip" title="log-out"  data-toggle="modal">
                            <i class="fa fa-sign-out"></i>  
                            <span>Log-Out</span>
                            <div class="clearfix"></div>
                        </a>                        
                    </li>									
				</ul>
		    </div>		
		    <div class="clearfix"></div>		            
		</div>          <?php
    }
    function script(){  ?>
        <script>            
            $(function () {
                $(".select2").select2();		
                $('.select2-input').addClass('form-control');                
            });
            window.onload = function() {
		        history.replaceState("", "", "");
	        }   	
            var toggle = true;										
            function toggleSideBar(){
                if (toggle){
                    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                    $("#menu span").css({"position":"absolute"});
                }
                else{
                    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                    setTimeout(function() {
                        $("#menu span").css({"position":"relative"});
                    }, 400);
                }								
                toggle = !toggle;
            }              		                     
        </script>    
        <script type="text/javascript" src="select2/bootstrap-select.min.js"></script>
        <script type="text/javascript" src="select2/select2.min.js"></script>
        <script type="text/javascript" src="select2/jquery.multi-select.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/bootstrap.min.js"></script>  <?php
    }   ?>
    <div id="logout" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md" >
            <form action="logout.php" method ="post">
                <div class="modal-content">
                    <div class="modal-header" style=" background-color: #3E3A86;color:#fff;">
                        <button type="button" class="close" style="color:#fff !important;opacity:1" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title" >
                            Stay Attention
                        </h4>
                    </div>
                    <div class="modal-body">
                    <h4 class="modal-title">
                            Confirm log-out
                        </h4>
                    </div>                                        
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-sm btn-primary" name="logout">Yes</button>
                        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    