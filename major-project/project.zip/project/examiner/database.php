<?php    
    // $host="localhost";
    // $user="id10912409_paperless_evaluation	";
    // $password="3002016123";
    // $database="id10912409_major_project	";                   
    $host="localhost";
    $user="root";
    $password="";
    $database="major_project";
    $con=mysqli_connect($host,$user,$password,$database);        
?>