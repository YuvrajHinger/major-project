<?php
    $host="localhost";
    $database="id10912409_major_project";
    $user="id10912409_paperless_evaluation";
    $password="3002016123";    
    $conn = new mysqli($host, $user, $password, $database);
?>